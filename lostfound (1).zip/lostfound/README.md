# Lost and Found Management System (Flask + SQLite)

## Run it
1. Install Python 3.9+ and open a terminal in this folder.
2. `pip install -r requirements.txt`
3. `python app.py`
4. Open http://127.0.0.1:5000

The database (`lostfound.db`) is created automatically on first run.

## Admin login
- Email: admin@lostfound.com
- Password: admin123

## Features
- User registration and login, admin login (same login page)
- Dashboard with counts and recent posts
- Report lost item / report found item, with image upload
- Search items and filter by category and lost/found
- Claim an item (admin approves or rejects)
- User profile with my posts and my claims
- Edit / delete posts, mark as returned
- Admin reports and statistics

## Files
- `app.py` - all routes and database code
- `templates/` - HTML pages
- `static/style.css` - all the styling (plain CSS, no Bootstrap)
- `static/uploads/` - uploaded item photos
