"""Lost and Found Management System - Flask + SQLite (simple version)."""
import os
import sqlite3
import uuid
from datetime import date
from functools import wraps

from flask import (Flask, abort, flash, g, redirect, render_template,
                   request, session, url_for)
from werkzeug.security import check_password_hash, generate_password_hash

BASE = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE, "lostfound.db")
UPLOAD_DIR = os.path.join(BASE, "static", "uploads")
ALLOWED_EXT = {"png", "jpg", "jpeg", "gif"}
CATEGORIES = ["Electronics", "Books", "ID / Cards", "Bags", "Keys",
              "Clothing", "Wallet", "Other"]

app = Flask(__name__)
app.secret_key = "change-this-secret-key"
app.config["MAX_CONTENT_LENGTH"] = 4 * 1024 * 1024  # 4 MB uploads


# ---------------------------------------------------------------- database
def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(_exc):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    db = sqlite3.connect(DB_PATH)
    db.executescript("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        phone TEXT,
        password TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'user'
    );
    CREATE TABLE IF NOT EXISTS items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL REFERENCES users(id),
        kind TEXT NOT NULL,              -- 'lost' or 'found'
        title TEXT NOT NULL,
        description TEXT,
        category TEXT NOT NULL,
        location TEXT,
        item_date TEXT,
        image TEXT,
        status TEXT NOT NULL DEFAULT 'open',   -- 'open' or 'returned'
        created TEXT DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS claims (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        item_id INTEGER NOT NULL REFERENCES items(id),
        user_id INTEGER NOT NULL REFERENCES users(id),
        message TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'pending', -- pending/approved/rejected
        created TEXT DEFAULT CURRENT_TIMESTAMP
    );
    """)
    # default admin account
    if not db.execute("SELECT 1 FROM users WHERE role='admin'").fetchone():
        db.execute("INSERT INTO users (name, email, password, role) VALUES (?,?,?,?)",
                   ("Admin", "admin@lostfound.com",
                    generate_password_hash("admin123"), "admin"))
    db.commit()
    db.close()


# ----------------------------------------------------------------- helpers
@app.before_request
def load_user():
    uid = session.get("user_id")
    g.user = (get_db().execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
              if uid else None)


def login_required(view):
    @wraps(view)
    def wrapped(*a, **kw):
        if g.user is None:
            flash("Please log in first.", "warning")
            return redirect(url_for("login"))
        return view(*a, **kw)
    return wrapped


def admin_required(view):
    @wraps(view)
    def wrapped(*a, **kw):
        if g.user is None or g.user["role"] != "admin":
            abort(403)
        return view(*a, **kw)
    return wrapped


def save_image(file):
    """Save an uploaded image and return its new filename (or None)."""
    if not file or not file.filename:
        return None
    ext = file.filename.rsplit(".", 1)[-1].lower()
    if ext not in ALLOWED_EXT:
        flash("Only png, jpg, jpeg or gif images are allowed.", "danger")
        return None
    name = f"{uuid.uuid4().hex}.{ext}"
    file.save(os.path.join(UPLOAD_DIR, name))
    return name


def get_item_or_404(item_id):
    item = get_db().execute(
        "SELECT items.*, users.name AS owner, users.email AS owner_email, "
        "users.phone AS owner_phone FROM items JOIN users ON users.id = items.user_id "
        "WHERE items.id=?", (item_id,)).fetchone()
    if item is None:
        abort(404)
    return item


def can_manage(item):
    return g.user and (g.user["id"] == item["user_id"] or g.user["role"] == "admin")


# ------------------------------------------------------------------ routes
@app.route("/")
def dashboard():
    db = get_db()
    counts = {
        "lost": db.execute("SELECT COUNT(*) FROM items WHERE kind='lost' AND status='open'").fetchone()[0],
        "found": db.execute("SELECT COUNT(*) FROM items WHERE kind='found' AND status='open'").fetchone()[0],
        "returned": db.execute("SELECT COUNT(*) FROM items WHERE status='returned'").fetchone()[0],
        "users": db.execute("SELECT COUNT(*) FROM users WHERE role='user'").fetchone()[0],
    }
    recent = db.execute(
        "SELECT items.*, users.name AS owner FROM items "
        "JOIN users ON users.id = items.user_id ORDER BY items.id DESC LIMIT 5").fetchall()
    # donut chart colours (lost = red, found = green, returned = indigo)
    total = counts["lost"] + counts["found"] + counts["returned"]
    if total:
        a = counts["lost"] / total * 360
        b = a + counts["found"] / total * 360
        donut = (f"conic-gradient(#ff4f3d 0 {a}deg, #8fbc9f {a}deg {b}deg, "
                 f"#4d4b8c {b}deg 360deg)")
        returned_pct = round(counts["returned"] / total * 100)
    else:
        donut, returned_pct = "conic-gradient(#dddddd 0 360deg)", 0
    return render_template("dashboard.html", counts=counts, recent=recent,
                           total=total, donut=donut, returned_pct=returned_pct)


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form["name"].strip()
        email = request.form["email"].strip().lower()
        phone = request.form["phone"].strip()
        pw = request.form["password"]
        if not name or not email or len(pw) < 6:
            flash("Fill all fields; password must be at least 6 characters.", "danger")
        else:
            try:
                get_db().execute(
                    "INSERT INTO users (name, email, phone, password) VALUES (?,?,?,?)",
                    (name, email, phone, generate_password_hash(pw)))
                get_db().commit()
                flash("Registered! Please log in.", "success")
                return redirect(url_for("login"))
            except sqlite3.IntegrityError:
                flash("That email is already registered.", "danger")
    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form["email"].strip().lower()
        user = get_db().execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
        if user and check_password_hash(user["password"], request.form["password"]):
            session.clear()
            session["user_id"] = user["id"]
            flash(f"Welcome, {user['name']}!", "success")
            return redirect(url_for("admin_panel" if user["role"] == "admin" else "dashboard"))
        flash("Wrong email or password.", "danger")
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    flash("Logged out.", "info")
    return redirect(url_for("dashboard"))


@app.route("/items")
def items():
    q = request.args.get("q", "").strip()
    category = request.args.get("category", "")
    kind = request.args.get("kind", "")
    sql, params = "SELECT * FROM items WHERE 1=1", []
    if q:
        sql += " AND (title LIKE ? OR description LIKE ? OR location LIKE ?)"
        params += [f"%{q}%"] * 3
    if category:
        sql += " AND category=?"
        params.append(category)
    if kind in ("lost", "found"):
        sql += " AND kind=?"
        params.append(kind)
    rows = get_db().execute(sql + " ORDER BY id DESC", params).fetchall()
    return render_template("items.html", items=rows, categories=CATEGORIES,
                           q=q, category=category, kind=kind)


@app.route("/report/<kind>", methods=["GET", "POST"])
@login_required
def report(kind):
    if kind not in ("lost", "found"):
        abort(404)
    if request.method == "POST":
        f = request.form
        if not f["title"].strip():
            flash("Title is required.", "danger")
        else:
            get_db().execute(
                "INSERT INTO items (user_id, kind, title, description, category, "
                "location, item_date, image) VALUES (?,?,?,?,?,?,?,?)",
                (g.user["id"], kind, f["title"].strip(), f["description"].strip(),
                 f["category"], f["location"].strip(), f["item_date"],
                 save_image(request.files.get("image"))))
            get_db().commit()
            flash(f"{kind.title()} item posted.", "success")
            return redirect(url_for("items"))
    return render_template("item_form.html", kind=kind, item=None,
                           categories=CATEGORIES, today=date.today().isoformat())


@app.route("/item/<int:item_id>")
def item_detail(item_id):
    item = get_item_or_404(item_id)
    claims = []
    my_claim = None
    if g.user:
        if can_manage(item):
            claims = get_db().execute(
                "SELECT claims.*, users.name AS claimer, users.email AS claimer_email "
                "FROM claims JOIN users ON users.id = claims.user_id "
                "WHERE item_id=? ORDER BY claims.id DESC", (item_id,)).fetchall()
        my_claim = get_db().execute(
            "SELECT * FROM claims WHERE item_id=? AND user_id=?",
            (item_id, g.user["id"])).fetchone()
    return render_template("item_detail.html", item=item, claims=claims,
                           my_claim=my_claim, can_manage=can_manage(item))


@app.route("/item/<int:item_id>/edit", methods=["GET", "POST"])
@login_required
def edit_item(item_id):
    item = get_item_or_404(item_id)
    if not can_manage(item):
        abort(403)
    if request.method == "POST":
        f = request.form
        image = save_image(request.files.get("image")) or item["image"]
        get_db().execute(
            "UPDATE items SET title=?, description=?, category=?, location=?, "
            "item_date=?, image=? WHERE id=?",
            (f["title"].strip(), f["description"].strip(), f["category"],
             f["location"].strip(), f["item_date"], image, item_id))
        get_db().commit()
        flash("Post updated.", "success")
        return redirect(url_for("item_detail", item_id=item_id))
    return render_template("item_form.html", kind=item["kind"], item=item,
                           categories=CATEGORIES, today=date.today().isoformat())


@app.route("/item/<int:item_id>/delete", methods=["POST"])
@login_required
def delete_item(item_id):
    item = get_item_or_404(item_id)
    if not can_manage(item):
        abort(403)
    get_db().execute("DELETE FROM claims WHERE item_id=?", (item_id,))
    get_db().execute("DELETE FROM items WHERE id=?", (item_id,))
    get_db().commit()
    flash("Post deleted.", "info")
    return redirect(url_for("profile" if g.user["role"] != "admin" else "admin_panel"))


@app.route("/item/<int:item_id>/returned", methods=["POST"])
@login_required
def mark_returned(item_id):
    item = get_item_or_404(item_id)
    if not can_manage(item):
        abort(403)
    get_db().execute("UPDATE items SET status='returned' WHERE id=?", (item_id,))
    get_db().commit()
    flash("Marked as returned.", "success")
    return redirect(url_for("item_detail", item_id=item_id))


@app.route("/item/<int:item_id>/claim", methods=["POST"])
@login_required
def claim_item(item_id):
    item = get_item_or_404(item_id)
    msg = request.form["message"].strip()
    if item["user_id"] == g.user["id"]:
        flash("You can't claim your own post.", "danger")
    elif item["status"] == "returned":
        flash("This item is already returned.", "danger")
    elif not msg:
        flash("Describe why this item is yours.", "danger")
    elif get_db().execute("SELECT 1 FROM claims WHERE item_id=? AND user_id=?",
                          (item_id, g.user["id"])).fetchone():
        flash("You already sent a claim for this item.", "warning")
    else:
        get_db().execute("INSERT INTO claims (item_id, user_id, message) VALUES (?,?,?)",
                         (item_id, g.user["id"], msg))
        get_db().commit()
        flash("Claim sent. The admin will verify it.", "success")
    return redirect(url_for("item_detail", item_id=item_id))


@app.route("/profile")
@login_required
def profile():
    db = get_db()
    my_items = db.execute("SELECT * FROM items WHERE user_id=? ORDER BY id DESC",
                          (g.user["id"],)).fetchall()
    my_claims = db.execute(
        "SELECT claims.*, items.title FROM claims JOIN items ON items.id = claims.item_id "
        "WHERE claims.user_id=? ORDER BY claims.id DESC", (g.user["id"],)).fetchall()
    return render_template("profile.html", my_items=my_items, my_claims=my_claims)


# ------------------------------------------------------------------- admin
@app.route("/admin")
@admin_required
def admin_panel():
    db = get_db()
    claims = db.execute(
        "SELECT claims.*, items.title, users.name AS claimer, users.email AS claimer_email "
        "FROM claims JOIN items ON items.id = claims.item_id "
        "JOIN users ON users.id = claims.user_id "
        "ORDER BY (claims.status='pending') DESC, claims.id DESC").fetchall()
    all_items = db.execute(
        "SELECT items.*, users.name AS owner FROM items "
        "JOIN users ON users.id = items.user_id ORDER BY items.id DESC").fetchall()
    return render_template("admin.html", claims=claims, all_items=all_items)


@app.route("/admin/claim/<int:claim_id>/<action>", methods=["POST"])
@admin_required
def review_claim(claim_id, action):
    if action not in ("approve", "reject"):
        abort(404)
    db = get_db()
    claim = db.execute("SELECT * FROM claims WHERE id=?", (claim_id,)).fetchone()
    if claim is None:
        abort(404)
    if action == "approve":
        db.execute("UPDATE claims SET status='approved' WHERE id=?", (claim_id,))
        db.execute("UPDATE items SET status='returned' WHERE id=?", (claim["item_id"],))
        flash("Claim approved and item marked as returned.", "success")
    else:
        db.execute("UPDATE claims SET status='rejected' WHERE id=?", (claim_id,))
        flash("Claim rejected.", "info")
    db.commit()
    return redirect(url_for("admin_panel"))


@app.route("/admin/stats")
@admin_required
def stats():
    db = get_db()
    q = lambda sql: db.execute(sql).fetchall()
    data = {
        "total": db.execute("SELECT COUNT(*) FROM items").fetchone()[0],
        "by_kind": q("SELECT kind, COUNT(*) AS n FROM items GROUP BY kind"),
        "by_status": q("SELECT status, COUNT(*) AS n FROM items GROUP BY status"),
        "by_category": q("SELECT category, COUNT(*) AS n FROM items GROUP BY category ORDER BY n DESC"),
        "claims": q("SELECT status, COUNT(*) AS n FROM claims GROUP BY status"),
        "users": db.execute("SELECT COUNT(*) FROM users WHERE role='user'").fetchone()[0],
    }
    return render_template("stats.html", d=data)


if __name__ == "__main__":
    init_db()
    app.run(debug=True)
